fx_version 'adamant'
games { 'gta5' }

server_scripts {
    "server/main.lua",
}
client_scripts {
    "client/main.lua",
}
ui_page {
    'nui/ui.html',
}
files {
    'nui/ui.html',
    'nui/css/main.css',
    'nui/js/app.js',
}
